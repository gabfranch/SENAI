def ler_inteiro(num):
    return num
    
num = int(input('Digite um número inteiro:'))

try:
    print(ler_inteiro(int(num)))
except ValueError:
    print('Valor inválido! Digite um número inteiro!')
    num = int(input('Digite um número inteiro:'))